classdef PPGFeat < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        PPGFeatUIFigure             matlab.ui.Figure
        fEditField                  matlab.ui.control.NumericEditField
        fEditFieldLabel             matlab.ui.control.Label
        SkipSsqiCheckBox            matlab.ui.control.CheckBox
        EnterSamplingfreqfilterfreqLabel  matlab.ui.control.Label
        FHEditField                 matlab.ui.control.NumericEditField
        FHEditFieldLabel            matlab.ui.control.Label
        FLEditField                 matlab.ui.control.NumericEditField
        F1Label                     matlab.ui.control.Label
        FsHzEditField               matlab.ui.control.NumericEditField
        FsHzEditFieldLabel          matlab.ui.control.Label
        Label_5                     matlab.ui.control.Label
        ExitButton                  matlab.ui.control.Button
        DataTextArea                matlab.ui.control.TextArea
        DataTextAreaLabel           matlab.ui.control.Label
        PlotpressedLamp             matlab.ui.control.Lamp
        PlotpressedLampLabel        matlab.ui.control.Label
        APGFiducialPointsLabel      matlab.ui.control.Label
        VPGFiducialPointsLabel      matlab.ui.control.Label
        PPGFiducialPointsLabel      matlab.ui.control.Label
        Label_2                     matlab.ui.control.Label
        GotonextwaveformLabel       matlab.ui.control.Label
        UpdatefeaturepointsusingmodifieduserdefinedvaluesLabel  matlab.ui.control.Label
        Plotallwaveformsusingmin1andmin2Label  matlab.ui.control.Label
        Yes0NoLabel                 matlab.ui.control.Label
        canddpresentEditField       matlab.ui.control.NumericEditField
        canddpresentEditFieldLabel  matlab.ui.control.Label
        StandardAPGFeaturesLabel    matlab.ui.control.Label
        StandardVPGFeaturesLabel    matlab.ui.control.Label
        StandardPPGFeaturesLabel    matlab.ui.control.Label
        eEditField                  matlab.ui.control.NumericEditField
        eEditFieldLabel             matlab.ui.control.Label
        dEditField                  matlab.ui.control.NumericEditField
        dEditFieldLabel             matlab.ui.control.Label
        cEditField                  matlab.ui.control.NumericEditField
        cmLabel                     matlab.ui.control.Label
        bEditField                  matlab.ui.control.NumericEditField
        bEditFieldLabel             matlab.ui.control.Label
        aEditField                  matlab.ui.control.NumericEditField
        aEditFieldLabel             matlab.ui.control.Label
        zEditField                  matlab.ui.control.NumericEditField
        zEditFieldLabel             matlab.ui.control.Label
        yEditField                  matlab.ui.control.NumericEditField
        yEditFieldLabel             matlab.ui.control.Label
        xEditField                  matlab.ui.control.NumericEditField
        xEditFieldLabel             matlab.ui.control.Label
        wEditField                  matlab.ui.control.NumericEditField
        wEditFieldLabel             matlab.ui.control.Label
        DEditField                  matlab.ui.control.NumericEditField
        DEditFieldLabel             matlab.ui.control.Label
        NEditField                  matlab.ui.control.NumericEditField
        NEditFieldLabel             matlab.ui.control.Label
        SEditField                  matlab.ui.control.NumericEditField
        SEditFieldLabel             matlab.ui.control.Label
        OEditField                  matlab.ui.control.NumericEditField
        OEditFieldLabel             matlab.ui.control.Label
        Lamp                        matlab.ui.control.Lamp
        Label                       matlab.ui.control.Label
        SsqiEditField               matlab.ui.control.NumericEditField
        SsqiEditFieldLabel          matlab.ui.control.Label
        UpdateButton                matlab.ui.control.Button
        SkipforbadSsqiButton        matlab.ui.control.Button
        unfit                       matlab.ui.control.Lamp
        acceptable                  matlab.ui.control.Lamp
        good                        matlab.ui.control.Lamp
        PPGsegmentAPGsegmentFeaturesSegmentlocationsLabel  matlab.ui.control.Label
        SQI082Good03SQI081AcceptableSQI03UnfitLabel  matlab.ui.control.Label
        GenerateoutputButton        matlab.ui.control.Button
        IDEditField                 matlab.ui.control.NumericEditField
        IDLabel                     matlab.ui.control.Label
        NextButton                  matlab.ui.control.Button
        PlotButton                  matlab.ui.control.Button
        Min2EditField               matlab.ui.control.NumericEditField
        Min2EditFieldLabel          matlab.ui.control.Label
        Min1EditField               matlab.ui.control.NumericEditField
        Image4                      matlab.ui.control.Image
        Min1EditFieldLabel          matlab.ui.control.Label
        CSVwithSsqianddataIDLabel   matlab.ui.control.Label
        LoadSsqiButton              matlab.ui.control.Button
        RAWPPGdataLabel             matlab.ui.control.Label
        LoadPPGButton               matlab.ui.control.Button
        Label_3                     matlab.ui.control.Label
        Image5                      matlab.ui.control.Image
        Image6                      matlab.ui.control.Image
        Label_4                     matlab.ui.control.Label
        UIAxes6                     matlab.ui.control.UIAxes
        UIAxes5                     matlab.ui.control.UIAxes
        UIAxes4                     matlab.ui.control.UIAxes
        UIAxes3                     matlab.ui.control.UIAxes
        UIAxes2                     matlab.ui.control.UIAxes
        UIAxes                      matlab.ui.control.UIAxes
    end

    
    properties (Access = private)
        loadedData % Description
        seg %to store ppg segment
        PPG_SEG % for PPG segment
        next % Description
        Ssqi % Description
        Sub_ID % Description
        PPG_filtered % Description
        Size_loaded_data % Description
        SEG_min_max % Description
        VPG % VPG segment
        APG % APG segment
        filter_sos % filter 
        g % storing filter
        APG_SEG %to store APG segment
        c_d_not % to detect the presence of c and d in APG
        APG_maxima %store all maxima of APG
        APG_minima %store all minima of APG
        c_d_APG %to store result of c and d presence
        Fs %sampling freq
        FL %filter low freq
        FH %filter high freq
        T2_5 %2.5 % of total length of selected segment

        % For PPG Segments
        O % Description
        S % Description
        N % Description
        D % Description

        % For VPG Segments
        W % Description
        X % Description
        Y % Description
        Z % Description

        % For APG Segments
        a % Description
        b % Description
        c % Description
        d % Description
        e % Description
        

        %Vectors for segment

        OSND %for PPG
        WXYZ %for VPG
        abcde %for APG
        feature %store feature table

        OSND_time % dt values of PPG
        WXYZ_time % dt values of VPG
        abcde_time % dt values of APG
        zero_c    % store zero crossing values

    end
    
    methods (Access = private)
        
        function  APG_c_d_test(app)
            app.c_d_not = 0;

            if (app.APG(app.APG_maxima(2)) > 0)  %means c and d is NOT present in APG
                app.c_d_not = 1;
                %disp(1)
                %app.NEditField.Value = app.APG_maxima(2);
                %app.DEditField.Value = app.APG_minima(2);

%                     hold(app.UIAxes5,"on")
%                     ll = [app.APG(app.APG_minima(1)) app.APG(app.APG_maxima(2))];
%                     plot(app.UIAxes5,[app.APG_minima(1) app.APG_maxima(2)],ll)
%                     hold(app.UIAxes5,"off")

                %app.cEditField.Value = (app.APG(app.APG_maxima(2))-app.APG(app.APG_minima(1)))/(app.APG_maxima(2)-app.APG_minima(1));
                %app.dEditField.Value = (app.APG_maxima(2)-app.APG_minima(1))/1000;
                app.c_d_APG(app.next) = 0;
                app.canddpresentEditField.Value = app.c_d_APG(app.next);
                %app.eEditField.Value = app.APG_maxima(2); 
                cal_c_d(app);
            end
%updated on 15th march
            if ((app.APG(app.APG_maxima(2))  < 0)  && ((app.APG_maxima(2)-app.APG_minima(2))<100)) %means c and d is present in APG
                app.c_d_not = 0; %to provide infor that c & d is present
                %disp(0)
                app.NEditField.Value = app.APG_maxima(3);
                app.DEditField.Value = app.APG_minima(3);
                app.cEditField.Value = app.APG_maxima(2);
                app.dEditField.Value = app.APG_minima(2);
                app.eEditField.Value = app.APG_maxima(3);
                app.fEditField.Value = app.APG_minima(3);
                app.c_d_APG(app.next) = 1;
                app.canddpresentEditField.Value = app.c_d_APG(app.next);
            else %changed 15th march
                app.c_d_APG(app.next) = 1;
                app.canddpresentEditField.Value = app.c_d_APG(app.next);
                cal_c_d(app);
            end
        end
        
        function updated_plot(app)
            %for PPG
            P_seg = plot(app.UIAxes2,app.seg);
            addToolbarExplorationButtons(P_seg);
            line(app.UIAxes2,[0 length(app.seg)],[0 0],'Color','red','LineStyle','--') %zero crossing line on segment
                for ii = 1:4
                    datatip(P_seg,app.OSND_time(ii),app.OSND(ii),'FontSize',8);
                end

            %for VPG
            P_vpg = plot(app.UIAxes6,app.VPG);
            addToolbarExplorationButtons(P_vpg);
            line(app.UIAxes6,[0 length(app.seg)],[0 0],'Color','red','LineStyle','--') %zero crossing line on segment
                for ii = 1:4
                    datatip(P_vpg,app.WXYZ_time(ii),app.WXYZ(ii),'FontSize',8);
                end

            %for APG
            P_apg = plot(app.UIAxes5,app.APG);
            addToolbarExplorationButtons(P_apg);
            line(app.UIAxes5,[0 length(app.seg)],[0 0],'Color','red','LineStyle','--') %zero crossing line on segment
                if ((app.canddpresentEditField.Value == 1)) %withh c and d, updated data tip
                        for ii = 1:5
                                datatip(P_apg,app.abcde_time(ii),app.abcde(ii),'FontSize',8);
                        end
                        datatip(P_apg,app.fEditField.Value,app.APG(app.fEditField.Value),'FontSize',8);
                end
                if ((app.canddpresentEditField.Value == 0)) %without c and d updated plot
% 
%                         datatip(P_apg,app.abcde_time(1),app.abcde(1),'FontSize',8);
%                         datatip(P_apg,app.abcde_time(2),app.abcde(2),'FontSize',8);
%                         datatip(P_apg,app.abcde_time(5),app.abcde(5),'FontSize',8);
%                         ll = [app.abcde(2) app.abcde(5)];
%                         hold(app.UIAxes5,"on")
%                         plot(app.UIAxes5,[app.abcde_time(2) app.abcde_time(5)],ll)
%                         hold(app.UIAxes5,"off")
                        for ii = 1:5
                                datatip(P_apg,app.abcde_time(ii),app.abcde(ii),'FontSize',8);
                        end
                         datatip(P_apg,app.fEditField.Value,app.APG(app.fEditField.Value),'FontSize',8);


                end
        end
        %%created zero crossing function on 9th jan
        function loc = zerocrossing(app,x)
            inew = 1;
            r = x;
            loc =0;
            for ch = 2:length(r)
                
                if (((r(ch-1)< 0) && (r(ch)> 0)) || ((r(ch-1)> 0) && (r(ch)< 0)))
                    loc(inew) = ch;
                    inew = inew + 1;
                end
            end
            app.zero_c = loc;
        end
        

         %%created function on 9th jan to implement methods for finding c
         %%and d uding new method
        function cal_c_d(app)
            z_apg = zerocrossing(app,app.APG);
            Jpg = diff(app.APG)*1000;
            Jpg = smoothdata(Jpg,"movmean",85);
            %plot(Jpg);
            max_index_jpg = islocalmax(Jpg,"MinProminence",40,"FlatSelection","all",...
                "MinSeparation",50,"MaxNumExtrema",5);
            min_index_jpg = islocalmin(Jpg,"MinProminence",50,"FlatSelection","all",...
                "MinSeparation",50,"MaxNumExtrema",5);

            max_value_jpg = find(max_index_jpg); %first point of jpg is not detected
            min_value_jpg  = find(min_index_jpg);
            z_jpg = zerocrossing(app,Jpg);

            %%To find values for c nd d using new method

            while (Jpg(min_value_jpg(2)) < 0)
                if (max_value_jpg(1) > min_value_jpg(1))

                    app.cEditField.Value = max_value_jpg(1);
                    app.dEditField.Value = z_apg(2);
                    A_APG_c = app.APG(app.cEditField.Value);
                    A_APG_d = app.APG(app.dEditField.Value);
                    app.eEditField.Value = z_jpg(3);
                    f = z_jpg(4);
                    app.fEditField.Value = f;
                    A_APG_e = app.APG(app.eEditField.Value);
                    A_APG_f = app.APG(f);
                    app.NEditField.Value = app.eEditField.Value;
                    app.DEditField.Value = f;
                    A_PPG_N = app.seg(app.NEditField.Value);
                    A_PPG_D = app.seg(app.DEditField.Value);
                    %disp("One")
                    break
                end

                if (max_value_jpg(2) > min_value_jpg(1))

                    app.cEditField.Value = max_value_jpg(2);
                    app.dEditField.Value = z_apg(2);
                    A_APG_c = app.APG(app.cEditField.Value);
                    A_APG_d = app.APG(app.dEditField.Value);
                    app.eEditField.Value = z_jpg(3);
                    f = z_jpg(4);
                    app.fEditField.Value = f;
                    A_APG_e = app.APG(app.eEditField.Value);
                    A_APG_f = app.APG(f);
                    app.NEditField.Value = app.eEditField.Value;
                    app.DEditField.Value = f;
                    A_PPG_N = app.seg(app.NEditField.Value);
                    A_PPG_D = app.seg(app.DEditField.Value);
                    %disp("Two")
                    break
                end

                if (max_value_jpg(3) > min_value_jpg(1))

                    app.cEditField.Value = max_value_jpg(3);
                    app.dEditField.Value = z_apg(2);
                    A_APG_c = app.APG(app.cEditField.Value);
                    A_APG_d = app.APG(app.dEditField.Value);
                    app.eEditField.Value = z_jpg(3);
                    f = z_jpg(4);
                    app.fEditField.Value = f;
                    A_APG_e = app.APG(app.eEditField.Value);
                    A_APG_f = app.APG(f);
                    app.NEditField.Value = app.eEditField.Value;
                    app.DEditField.Value = f;
                    A_PPG_N = app.seg(app.NEditField.Value);
                    A_PPG_D = app.seg(app.DEditField.Value);
                    %disp("three")
                    break
                end
            end


            while (Jpg(min_value_jpg(2)) >0)
                if (app.APG_maxima(2) < 0)
                    app.cEditField.Value = app.APG_maxima(2);
                    app.dEditField.Value = app.APG_minima(2);
                    A_APG_c = app.APG(app.cEditField.Value);
                    A_APG_d = app.APG(app.dEditField.Value);
                    app.eEditField.Value = z_jpg(3);
                    f = z_jpg(4);
                    app.fEditField.Value = f;
                    A_APG_e = app.APG(app.eEditField.Value);
                    A_APG_f = app.APG(f);
                    app.NEditField.Value = app.eEditField.Value;
                    app.DEditField.Value = f;
                    A_PPG_N = app.seg(app.NEditField.Value);
                    A_PPG_D = app.seg(app.DEditField.Value);
                    %disp("c d founded in APG")
                    break
                end

                if (app.APG_maxima(2) > 0)
                    %disp(app.T2_5)
                    app.cEditField.Value = min_value_jpg(2)- app.T2_5;
                    app.dEditField.Value = min_value_jpg(2)+ app.T2_5;
                    A_APG_c = app.APG(app.cEditField.Value);
                    A_APG_d = app.APG(app.dEditField.Value);
                    app.eEditField.Value = z_jpg(3);
                    f = z_jpg(4);
                    app.fEditField.Value = f;
                    A_APG_e = app.APG(app.eEditField.Value);
                    A_APG_f = app.APG(f);
                    app.NEditField.Value = app.eEditField.Value;
                    app.DEditField.Value = f;
                    A_PPG_N = app.seg(app.NEditField.Value);
                    A_PPG_D = app.seg(app.DEditField.Value);
                    %disp("c d founded in JPG + -20")
                    break
                end

            end


        end
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Button pushed function: LoadPPGButton
        function LoadPPGButtonPushed(app, event)


           

            %start the counter for reading all PPG data
            app.next = 1;

            %read initial parameters for filter
            app.Fs = app.FsHzEditField.Value;
            app.FL = app.FLEditField.Value;
            app.FH = app.FHEditField.Value;



            %open file path
            [file,path]= uigetfile('*.csv');  %read CVS file
            filename = [path file];
            app.loadedData = importdata(filename);  %load all RAW data
            plot(app.UIAxes4,app.loadedData(1,:))  %Plot first RAW waveform
            %plot(app.UIAxes,app.loadedData(1,:))  %Plot first waveform

            app.Size_loaded_data = size(app.loadedData); %read size of loaded data
            
            %variable to store location of min and max with data id
            app.SEG_min_max = zeros(app.Size_loaded_data(1),3);

            app.PPG_filtered = zeros(app.Size_loaded_data); %Create matrix to store filtered PPG
            app.PPG_SEG = zeros(app.Size_loaded_data(1),(app.Size_loaded_data(2)-(app.Size_loaded_data(2)/3))) ; %create matrix to store segment

            %VPG data base
            %app.VPG = zeros(app.Size_loaded_data(1),(app.Size_loaded_data(2)-700)) ;
            
            % APG database
            app.APG_SEG = zeros(app.Size_loaded_data(1),(app.Size_loaded_data(2)-(app.Size_loaded_data(2)/3))) ;

            %show data numbr in the text area 
            Dat1 = num2str(app.Size_loaded_data(1));
            Dat2 = num2str(app.next);
            Dat = Dat2 + " of " + Dat1;
            app.DataTextArea.Value = Dat;
            %app.DataTextArea.Value = num2str(app.next);


                        %test about SQI
            if (app.SkipSsqiCheckBox.Value == true)
                %disp('true')
                %A = ones(app.Size_loaded_data(1),2);
                A = ones(app.Size_loaded_data(1),1);
                B = 1:1:app.Size_loaded_data(1);
                B = B';
                app.Ssqi = [A B];


                app.SsqiEditField.Value = app.Ssqi(app.next,1);
                app.Sub_ID = app.Ssqi(app.next,2);
                app.IDEditField.Value = app.Sub_ID;
    
                if app.SsqiEditField.Value > 0.8
                    app.Lamp.Color = 'g';
                end
    
                if (app.SsqiEditField.Value < 0.8) && (app.SsqiEditField.Value >= 0.3)
                    app.Lamp.Color = 'y';
    
                end
    
                if app.SsqiEditField.Value < 0.3
                    app.Lamp.Color = 'r';
                end
    
                app.PlotpressedLamp.Color = 'r';
            end

            %Create Filter 
            % Read all PPG RAW data and apply filters and store

            [A,B,C,F] = cheby2(4,20,[app.FL app.FH]/(app.Fs/2));
            Fil = designfilt('bandpassiir','FilterOrder',4, ...
                'StopbandFrequency1',app.FL,'StopbandFrequency2',app.FH, ...
                'StopbandAttenuation',20,'SampleRate',app.Fs);
            [app.filter_sos , app.g] = ss2sos(A,B,C,F);
            
            for i = 1:app.Size_loaded_data(1)
                %apply filter to all data

                filtered_data = filtfilt(app.filter_sos,app.g,app.loadedData(i,:));

                %normalizing the data
                m = mean(filtered_data);
                st = std(filtered_data);
                app.PPG_filtered(i,:) = (filtered_data - m)/st; %store filtered data
                %PPG_FILTERED(i,:) = smoothdata(PPG_FILTERED(i,:),"gaussian","SmoothingFactor",0.25);

            end

            %plot the filtered PPG and show the maxima and minima
            filtered_data = app.PPG_filtered(app.next ,:);
            PPG = plot(app.UIAxes,filtered_data ); %Plot filtered PPG
            addToolbarExplorationButtons(PPG);
            grid(app.UIAxes,"on")

                        %find maxima and minima of current segment
            PPG_max = islocalmax(filtered_data ,"MinProminence",0.1,"FlatSelection","all",...
                "MinSeparation",200,"MaxNumExtrema",10);
            PPG_min = islocalmin(filtered_data ,"MinProminence",0.1,"FlatSelection","all",...
                "MinSeparation",100,"MaxNumExtrema",10);

            index_PPG_max = find(PPG_max); %index of maxima points
            value_PPG_max = filtered_data(PPG_max);  %value at maxima point

            index_PPG_min = find( PPG_min) ; %index of maxima points
            value_PPG_min = filtered_data( PPG_min) ;  %value at maxima point



            if (~isempty(index_PPG_max))
                %ax = gca;
                %chart = ax.Children();
                for ii = 1:length(index_PPG_max)
                    datatip(PPG,index_PPG_max(ii),value_PPG_max(ii),'FontSize',8);
                end
            end


            if (~isempty(index_PPG_min))
%                 ax = gca;
%                 chart = ax.Children();
                for ij = 1:length(index_PPG_min)
                    datatip(PPG,index_PPG_min(ij),value_PPG_min(ij),'FontSize',8,'Location','southeast');
                end
            end

            %read min1 and min from ppg waveform and show in the edit field

                app.Min1EditField.Value = index_PPG_min(1);
                app.Min2EditField.Value = index_PPG_min(2);

            %initialize the variables
            app.OSND = zeros(1,4);
            app.WXYZ = zeros(1,4);
            app.abcde = zeros(1,5);
            app.feature = zeros(219,30);
            app.c_d_APG = zeros(219,1);

          
        end

        % Button pushed function: PlotButton
        function PlotButtonPushed(app, event)
            app.PlotpressedLamp.Color = 'g'; %to show user that the plot button has not been pressed
            
            %plot the segment using the manual input values from min1 and
            %min2
            min1 = app.Min1EditField.Value-15;
            min2 = app.Min2EditField.Value+15;
            app.seg = app.PPG_filtered(app.next,min1:min2);
            %app.seg = normalize(app.seg,"range");
            %calculate and filter VPG

            %calculate 2.5% of T
            app.T2_5 = floor((((min2 - min1)-30)/100)*2.5);
          %disp(app.T2_5)


            app.VPG  = diff(app.seg)*1000;
            app.VPG = smoothdata(app.VPG,"movmean",50); %data smoothing using 50 ms window
            %app.VPG = filtfilt(app.filter_sos,app.g,app.VPG);

            %calculate and filter APG
            app.APG  = diff(app.VPG)*1000;
            app.APG  = smoothdata(app.APG,"movmean",65); %data smoothing using 65 ms window
            %app.APG = filtfilt(app.filter_sos,app.g,app.APG );

            %create matrix for segment information

            app.SEG_min_max(app.next,1) = app.Sub_ID;
            app.SEG_min_max(app.next,2) = min1;
            app.SEG_min_max(app.next,3) = min2;
            app.SEG_min_max;

            %plot the PPG segment
            P_seg = plot(app.UIAxes2,app.seg);
            addToolbarExplorationButtons(P_seg);
            grid(app.UIAxes2,"on")

            line(app.UIAxes2,[0 length(app.seg)],[0 0],'Color','red','LineStyle','--') %zero crossing line on segment

            %find maxima and minima of current segment
            PPG_SEG_max = islocalmax(app.seg,"MinProminence",0.1,"FlatSelection","all",...
                "MinSeparation",10,"MaxNumExtrema",2);
            PPG_SEG_min = islocalmin(app.seg,"MinProminence",0.01,"FlatSelection","all",...
                "MinSeparation",10,"MaxNumExtrema",3);

            index_max = find(PPG_SEG_max); %index of maxima points
            value_max = app.seg(PPG_SEG_max);  %value at maxima point

            index_min = find( PPG_SEG_min) ; %index of maxima points
            value_min = app.seg( PPG_SEG_min) ;  %value at maxima point

            if (~isempty(index_max))
                %ax = gca;
                %chart = ax.Children();
                for ii = 1:length(index_max)
                    datatip(P_seg,index_max(ii),value_max(ii),'FontSize',8);
                end
            end


            if (~isempty(index_min))
%                 ax = gca;
%                 chart = ax.Children();
                for ij = 1:length(index_min)
                    datatip(P_seg,index_min(ij),value_min(ij),'FontSize',8,'Location','southeast');
                end
            end


            %plot VPG
            P_vpg = plot(app.UIAxes6,app.VPG);
            addToolbarExplorationButtons(P_vpg);
            grid(app.UIAxes6,"on")

            line(app.UIAxes6,[0 length(app.seg)],[0 0],'Color','red','LineStyle','--') %zero crossing line on segment

            %find maxima and minima of current segment
            PPG_vpg_max = islocalmax(app.VPG,"MinProminence",0.2,"FlatSelection","all",...
                "MinSeparation",50,"MaxNumExtrema",3);
            PPG_vpg_min = islocalmin(app.VPG,"MinProminence",0.2,"FlatSelection","all",...
                "MinSeparation",50,"MaxNumExtrema",2);

            index_max_vpg = find(PPG_vpg_max); %index of maxima points
            value_max_vpg = app.VPG(PPG_vpg_max);  %value at maxima point

            index_min_vpg = find( PPG_vpg_min) ; %index of maxima points
            value_min_vpg = app.VPG( PPG_vpg_min) ;  %value at maxima point

            if (~isempty(index_max_vpg))

                for ii = 1:length(index_max_vpg)
                    datatip(P_vpg,index_max_vpg (ii),value_max_vpg(ii),'FontSize',8);
                end
            end


            if (~isempty(index_min_vpg))

                for ij = 1:length(index_min_vpg)

                    datatip(P_vpg,index_min_vpg(ij),value_min_vpg(ij),'FontSize',8,'Location','southeast');
                end
            end

            %plot APG
            P_apg = plot(app.UIAxes5,app.APG);
            addToolbarExplorationButtons(P_apg);
            grid(app.UIAxes5,"on")

            line(app.UIAxes5,[0 length(app.seg)],[0 0],'Color','red','LineStyle','--') %zero crossing line on segment

            %find maxima and minima of current segment
            small = length(app.seg);
                PPG_apg_max = islocalmax(app.APG,"MinProminence",1.5,"FlatSelection","all",...
                    "MinSeparation",50,"MaxNumExtrema",5);
                PPG_apg_min = islocalmin(app.APG,"MinProminence",1.5,"FlatSelection","all",...
                    "MinSeparation",50,"MaxNumExtrema",5);

                index_max_apg = find(PPG_apg_max); %index of maxima points
                value_max_apg = app.APG(PPG_apg_max);  %value at maxima point

                index_min_apg = find( PPG_apg_min) ; %index of maxima points
                value_min_apg = app.APG( PPG_apg_min) ;  %value at maxima point



%                 if (app.c_d_not == 1) %means c and d is NOT present in APG
%                     hold(app.UIAxes5,"on")
%                     ll = [app.APG(index_min_apg(1)) app.APG(index_max_apg(2))];
%                     plot(app.UIAxes5,[index_min_apg(1) index_max_apg(2)],ll)
%                     hold(app.UIAxes5,"off")
%                     app.eEditField.Value = index_max_apg(2); 
% 
%                 end
% new code on 15th MARCH 2023 to check two points close to each other
if abs(index_min_apg(1) - index_max_apg(1)) <= 50
    disp('The first minimum and maximum are close to each other by 50 units.');
    % Shift the index_min_apg vector by 1
    index_min_apg = index_min_apg(2:end);
    value_min_apg = value_min_apg(2:end);
end

                if (~isempty(index_max_apg))

                    for ii = 1:length(index_max_apg)
                        datatip(P_apg,index_max_apg (ii),value_max_apg(ii),'FontSize',8);

                    end
                end


                if (~isempty(index_min_apg))

                    for ij = 1:length(index_min_apg)

                        datatip(P_apg,index_min_apg(ij),value_min_apg(ij),'FontSize',8,'Location','southeast');
                    end
                end

            %length(app.seg)
%cal_c_d(app)  %%to test the function


%corrected datatips and indexes of APG
                app.APG_maxima = index_max_apg ;
                app.APG_minima = index_min_apg ;


            %read all the feature points from PPG VPG and APG
            app.OEditField.Value = index_min(1);
            app.SEditField.Value = index_max(1);

            APG_c_d_test(app) %check the presence of c and d

            datatip(P_seg,app.NEditField.Value,app.seg(app.NEditField.Value),'FontSize',8);
            datatip(P_seg,app.DEditField.Value,app.seg(app.DEditField.Value),'FontSize',8);
            %disp(app.NEditField.Value)
            %app.NEditField.Value = index_max_apg(3); 
            %app.DEditField.Value = index_max_vpg(2); 

            app.OSND = [app.seg(app.OEditField.Value) app.seg(app.SEditField.Value) app.seg(app.NEditField.Value) app.seg(app.DEditField.Value)];
            %disp(app.OSND)
            


            app.wEditField.Value = index_max_vpg(1); 
            app.xEditField.Value = index_max(1); 
            app.yEditField.Value = index_min_vpg(1); 
            app.zEditField.Value = index_max_vpg(2); 
            datatip(P_vpg,app.xEditField.Value,app.VPG(app.xEditField.Value),'FontSize',8);

            app.WXYZ = [app.VPG(app.wEditField.Value) app.VPG(app.xEditField.Value) app.VPG(app.yEditField.Value) app.VPG(app.zEditField.Value)];
            %disp(app.WXYZ)

            app.aEditField.Value = index_max_apg(1); 
            app.bEditField.Value = index_min_apg(1); 
            %app.cEditField.Value = index_max_apg(2); 
            %app.dEditField.Value = index_min_apg(2); 
            %app.eEditField.Value = index_max_apg(3); 

            if (app.c_d_not == 1) %means c and d is NOT present in APG
            app.abcde = [app.APG(app.aEditField.Value) app.APG(app.bEditField.Value) app.APG(app.cEditField.Value) app.APG(app.dEditField.Value) app.APG(app.eEditField.Value)];
            %disp(app.abcde)
            end

            if (app.c_d_not == 0) %means c and d is present in APG
            app.abcde = [app.APG(app.aEditField.Value) app.APG(app.bEditField.Value) app.APG(app.cEditField.Value) app.APG(app.dEditField.Value) app.APG(app.eEditField.Value)];
            %disp(app.abcde)
            end

            %time variables of all waveform
            app.OSND_time  = [app.OEditField.Value app.SEditField.Value app.NEditField.Value app.DEditField.Value];
            app.WXYZ_time  = [app.wEditField.Value app.xEditField.Value app.yEditField.Value app.zEditField.Value];
            app.abcde_time = [app.aEditField.Value app.bEditField.Value app.cEditField.Value app.dEditField.Value app.eEditField.Value];

            %for f values of APG
            F_Value = app.APG(app.fEditField.Value);
            F_t = app.fEditField.Value;
            %for On+1 values of PPG
            O_next_t = ((app.Min2EditField.Value - app.Min1EditField.Value) + 16);
            %disp(O_next)
            O_next = app.seg(O_next_t);
            %feature table
            app.feature(app.next,:) = [app.OSND O_next app.WXYZ app.abcde F_Value app.OSND_time O_next_t app.WXYZ_time app.abcde_time F_t];
            %disp(app.feature)

            %store segments by zero padding remaining values
            app.PPG_SEG(app.next,:) = [app.seg zeros(1,(app.Size_loaded_data(2)-700)-length(app.seg))];

            app.APG_SEG(app.next,:) = [app.APG zeros(1,(app.Size_loaded_data(2)-700)-length(app.APG))];

            %plot overall PPG segments
            hold(app.UIAxes3,"on")
            plot(app.UIAxes3,app.seg)
            hold(app.UIAxes3,"off")
          
            %store segment min and max for data recording purpose

        end

        % Button pushed function: GenerateoutputButton
        function GenerateoutputButtonPushed(app, event)
            %save segmented data of PPG for zero padded values

            PPG_segment = 'PPG_Segments.xlsx';
            writematrix(app.PPG_SEG,PPG_segment)
            PPG = app.PPG_SEG;

            %save segmented data of APG for zero padded values

            APG_segment = 'APG_Segments.xlsx';
            writematrix(app.APG_SEG,APG_segment)
            APG_s = app.APG_SEG;

            %save location of min and max with segment
            ID_min_max = 'ID_min1_min2.xlsx';
            writematrix(app.SEG_min_max, ID_min_max)
            SMM = app.SEG_min_max;


            %save filtered data of the whole input PPG 219 x 2100
            PPG_filter = 'PPG_Filtered_HighSQI.xlsx';
            writematrix(app.PPG_filtered,PPG_filter )
            PPG_fil = app.PPG_filtered;

            %save feature table
         
            PPG_feature = 'PPG_features.xlsx';
            writematrix(app.feature,PPG_feature )
            P_feat = app.feature;

            %save c and d presence table
            c_and_d = 'c_d_presence.xlsx';
            writematrix(app.c_d_APG,c_and_d)
            C_D = app.c_d_APG;

            save 'Results30Jan' 'PPG' 'APG_s' 'SMM' 'P_feat' PPG_fil 'C_D','-mat';
            %ExitButtonPushed(app, event)
        end

        % Button pushed function: NextButton
        function NextButtonPushed(app, event)
            
            app.next = app.next+1;  %increase the counter for next value

            %alert on 2nd last data
            if (app.next+1 == app.Size_loaded_data(1))
            msgbox("This is second last data","Alert","warn");
            end

            %autosave onlast data
            if (app.next > app.Size_loaded_data(1))
            msgbox("Auto saving","Alert","warn");
            GenerateoutputButtonPushed(app, event)
            ExitButtonPushed(app, event)
            end

            app.IDEditField.Value = app.next;
            plot(app.UIAxes4,app.loadedData(app.next ,:)) %plot RAW
            
           %plot the filtered PPG and show the maxima and minima
            filtered_data = app.PPG_filtered(app.next ,:);

            PPG = plot(app.UIAxes,filtered_data ); %Plot filtered PPG
            addToolbarExplorationButtons(PPG);
            grid(app.UIAxes,"on")
            
 

                        %find maxima and minima of current segment
            PPG_max = islocalmax(filtered_data ,"MinProminence",0.1,"FlatSelection","all",...
                "MinSeparation",200,"MaxNumExtrema",4);
            PPG_min = islocalmin(filtered_data ,"MinProminence",0.01,"FlatSelection","all",...
                "MinSeparation",200,"MaxNumExtrema",4);

            index_PPG_max = find(PPG_max); %index of maxima points
            value_PPG_max = filtered_data(PPG_max);  %value at maxima point

            index_PPG_min = find( PPG_min) ; %index of maxima points
            value_PPG_min = filtered_data( PPG_min) ;  %value at maxima point

            if (~isempty(index_PPG_max))
                %ax = gca;
                %chart = ax.Children();
                for ii = 1:length(index_PPG_max)
                    datatip(PPG,index_PPG_max(ii),value_PPG_max(ii),'FontSize',8);
                end
            end


            if (~isempty(index_PPG_min))
%                 ax = gca;
%                 chart = ax.Children();
                for ij = 1:length(index_PPG_min)
                    datatip(PPG,index_PPG_min(ij),value_PPG_min(ij),'FontSize',8,'Location','southeast');
                end
            end

            %read min1 and min from ppg waveform and show in the edit field
            
%%check for distance between mins.. call some function

% Set the threshold value for comparing the minima indices
            threshold = 40 * app.Fs/100;
            
            % Loop over all minima indices
            for i = 1:length(index_PPG_min)-1
                
                % Check if the next minimum index is greater than the current one by
                % the threshold value
                if index_PPG_min(i+1) > index_PPG_min(i) + threshold
                    % If yes, check if there is any maximum index between the two minima
                    maxima_between_minima = index_PPG_max(index_PPG_max > index_PPG_min(i) & index_PPG_max < index_PPG_min(i+1));
                    if ~isempty(maxima_between_minima)
                        
                        % Add any other code you need to perform here
                    app.Min1EditField.Value = index_PPG_min(i);
                    app.Min2EditField.Value = index_PPG_min(i+1);
                    break
                    end
                end
            end



            app.SsqiEditField.Value = app.Ssqi(app.next,1); %display SQI from the input table

            app.Sub_ID = app.Ssqi(app.next,2);  %display subject ID from the input table
            app.IDEditField.Value = app.Sub_ID;
            
            if app.SsqiEditField.Value > 0.8
                app.Lamp.Color = 'g';
            end

            if (app.SsqiEditField.Value < 0.8) && (app.SsqiEditField.Value >= 0.3)
                app.Lamp.Color = 'y';

            end

            if app.SsqiEditField.Value < 0.3
                app.Lamp.Color = 'r';
            end

           app.PlotpressedLamp.Color = 'r';  %to show user that the plot button has not been pressed

           %show data numbr in the text area 
           Dat1 = num2str(app.Size_loaded_data(1));
            Dat2 = num2str(app.next);
            Dat = Dat2 + " of " + Dat1;
            app.DataTextArea.Value = Dat;
        end

        % Button pushed function: LoadSsqiButton
        function LoadSsqiButtonPushed(app, event)
            %AA = 0;
            [file1,path1]= uigetfile('*.csv');
            filename1 = [path1 file1];
            app.Ssqi= importdata(filename1);
            %AA = app.Ssqi.data(:,3);
            app.SsqiEditField.Value = app.Ssqi(app.next,1);
            app.Sub_ID = app.Ssqi(app.next,2);
            app.IDEditField.Value = app.Sub_ID;

            if app.SsqiEditField.Value > 0.8
                app.Lamp.Color = 'g';
            end

            if (app.SsqiEditField.Value < 0.8) && (app.SsqiEditField.Value >= 0.3)
                app.Lamp.Color = 'y';

            end

            if app.SsqiEditField.Value < 0.3
                app.Lamp.Color = 'r';
            end

            app.PlotpressedLamp.Color = 'r';
           
        end

        % Button pushed function: SkipforbadSsqiButton
        function SkipforbadSsqiButtonPushed(app, event)
            NextButtonPushed(app, event);
            %          app.next = app.next+1;  %increase the counter for next value
%             app.IDEditField.Value = app.next;
%             plot(app.UIAxes4,app.loadedData(app.next ,:)) %plot RAW
%             
%             plot(app.UIAxes,app.PPG_filtered(app.next ,:)) %Plot filtered
% 
%             app.SsqiEditField.Value = app.Ssqi(app.next,1);
% 
%             app.Sub_ID = app.Ssqi(app.next,2);
%             app.IDEditField.Value = app.Sub_ID;
%             
%             if app.SsqiEditField.Value > 0.8
%                 app.Lamp.Color = 'g';
%             end
% 
%             if (app.SsqiEditField.Value < 0.8) && (app.SsqiEditField.Value >= 0.3)
%                 app.Lamp.Color = 'y';
% 
%             end
% 
%             if app.SsqiEditField.Value < 0.3
%                 app.Lamp.Color = 'r';
%             end

        end

        % Button pushed function: UpdateButton
        function UpdateButtonPushed(app, event)
            %%Value update for PPG
            app.OSND(1) = app.OEditField.Value; 
            app.OEditField.Value = app.OSND(1);

            app.OSND(2) = app.SEditField.Value; 
            app.SEditField.Value = app.OSND(2);

            app.OSND(3) = app.NEditField.Value; 
            app.NEditField.Value = app.OSND(3);

            app.OSND(4) = app.DEditField.Value; 
            app.DEditField.Value = app.OSND(4);

            app.OSND = [app.seg(app.OEditField.Value) app.seg(app.SEditField.Value) app.seg(app.NEditField.Value) app.seg(app.DEditField.Value)];
            %app.OSND = [app.OEditField.Value app.SEditField.Value app.NEditField.Value app.DEditField.Value];
            %app.OSND = [app.OEditField.Value app.SEditField.Value app.NEditField.Value app.DEditField.Value];
            %disp(app.OSND)

            %Value update for VPG
            app.WXYZ(1) = app.wEditField.Value;
            app.wEditField.Value = app.WXYZ(1); 

            app.WXYZ(2) = app.xEditField.Value;
            app.xEditField.Value = app.WXYZ(2); 

            app.WXYZ(3) = app.yEditField.Value;
            app.yEditField.Value = app.WXYZ(3); 

            app.WXYZ(4) = app.zEditField.Value;
            app.zEditField.Value = app.WXYZ(4); 

            app.WXYZ = [app.VPG(app.wEditField.Value) app.VPG(app.xEditField.Value) app.VPG(app.yEditField.Value) app.VPG(app.zEditField.Value)];
            %app.WXYZ = [app.wEditField.Value app.xEditField.Value app.yEditField.Value app.zEditField.Value];
            %app.OSND = [app.OEditField.Value app.SEditField.Value app.NEditField.Value app.DEditField.Value];
            %disp(app.WXYZ)

            %value update for APG
            app.abcde(1) = app.aEditField.Value;
            app.aEditField.Value = app.abcde(1); 

            app.abcde(2) = app.bEditField.Value;
            app.bEditField.Value = app.abcde(2); 

            app.abcde(3) = app.cEditField.Value;
            app.cEditField.Value = app.abcde(3); 

            app.abcde(4) = app.dEditField.Value;
            app.dEditField.Value = app.abcde(4); 

            app.abcde(5) = app.eEditField.Value;
            app.eEditField.Value = app.abcde(5); 

            app.c_d_APG(app.next) = app.canddpresentEditField.Value;
            if (app.c_d_APG(app.next) == 0) %means c and d is NOT present in APG

                app.cEditField.Value = app.cEditField.Value;
                app.dEditField.Value = app.dEditField.Value;

%                 ll = [app.APG(app.abcde(2)) app.APG(app.abcde(5))];
%                 hold(app.UIAxes5,"on")
%                 plot(app.UIAxes5,[app.abcde(2) app.abcde(5)],[app.APG(app.abcde(2)) app.APG(app.abcde(5))])
%                 hold(app.UIAxes5,"off")

            app.abcde = [app.APG(app.aEditField.Value) app.APG(app.bEditField.Value) app.APG(app.cEditField.Value) app.APG(app.dEditField.Value) app.APG(app.eEditField.Value)];
            %disp(app.abcde)
            end

            if (app.c_d_APG(app.next) == 1) %means c and d is present in APG
            app.abcde = [app.APG(app.aEditField.Value) app.APG(app.bEditField.Value) app.APG(app.cEditField.Value) app.APG(app.dEditField.Value) app.APG(app.eEditField.Value)];
            %disp(app.abcde)
            end
            %time variables of all waveform
            app.OSND_time  = [app.OEditField.Value app.SEditField.Value app.NEditField.Value app.DEditField.Value];
            app.WXYZ_time  = [app.wEditField.Value app.xEditField.Value app.yEditField.Value app.zEditField.Value];
            app.abcde_time = [app.aEditField.Value app.bEditField.Value app.cEditField.Value app.dEditField.Value app.eEditField.Value];
            
            %for f values of APG
            F_Value = app.APG(app.fEditField.Value);
            F_t = app.fEditField.Value;
            %for On+1 values of PPG
            O_next_t = ((app.Min2EditField.Value - app.Min1EditField.Value) + 16);
            %disp(O_next)
            O_next = app.seg(O_next_t);
            %feature table
            app.feature(app.next,:) = [app.OSND O_next app.WXYZ app.abcde F_Value app.OSND_time O_next_t app.WXYZ_time app.abcde_time F_t];
            %disp(app.feature)
            
            %update table value for c and d
            app.c_d_APG(app.next) = app.canddpresentEditField.Value;

            %update the figues
            updated_plot(app)
            grid(app.UIAxes5,"on")

        end

        % Button pushed function: ExitButton
        function ExitButtonPushed(app, event)
            delete(app.PPGFeatUIFigure)
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Get the file path for locating images
            pathToMLAPP = fileparts(mfilename('fullpath'));

            % Create PPGFeatUIFigure and hide until all components are created
            app.PPGFeatUIFigure = uifigure('Visible', 'off');
            app.PPGFeatUIFigure.Color = [0.9412 0.9412 0.9412];
            app.PPGFeatUIFigure.Position = [100 100 1353 857];
            app.PPGFeatUIFigure.Name = 'PPGFeat';

            % Create UIAxes
            app.UIAxes = uiaxes(app.PPGFeatUIFigure);
            title(app.UIAxes, 'Filtered PPG')
            xlabel(app.UIAxes, 'Samples')
            ylabel(app.UIAxes, 'Normalized values')
            zlabel(app.UIAxes, 'Z')
            app.UIAxes.Position = [192 309 484 242];

            % Create UIAxes2
            app.UIAxes2 = uiaxes(app.PPGFeatUIFigure);
            title(app.UIAxes2, 'PPG Segment')
            xlabel(app.UIAxes2, 'X')
            ylabel(app.UIAxes2, 'Y')
            zlabel(app.UIAxes2, 'Z')
            app.UIAxes2.Position = [675 569 350 242];

            % Create UIAxes3
            app.UIAxes3 = uiaxes(app.PPGFeatUIFigure);
            title(app.UIAxes3, 'PPG Segments')
            xlabel(app.UIAxes3, 'Samples')
            ylabel(app.UIAxes3, 'Normalized Values')
            zlabel(app.UIAxes3, 'Z')
            app.UIAxes3.Position = [192 11 484 247];

            % Create UIAxes4
            app.UIAxes4 = uiaxes(app.PPGFeatUIFigure);
            title(app.UIAxes4, 'RAW PPG')
            xlabel(app.UIAxes4, 'Samples')
            ylabel(app.UIAxes4, 'Amplitude')
            zlabel(app.UIAxes4, 'Z')
            app.UIAxes4.Position = [192 569 484 242];

            % Create UIAxes5
            app.UIAxes5 = uiaxes(app.PPGFeatUIFigure);
            title(app.UIAxes5, 'APG')
            xlabel(app.UIAxes5, 'X')
            ylabel(app.UIAxes5, 'Y')
            zlabel(app.UIAxes5, 'Z')
            app.UIAxes5.Position = [675 11 352 246];

            % Create UIAxes6
            app.UIAxes6 = uiaxes(app.PPGFeatUIFigure);
            title(app.UIAxes6, 'VPG')
            xlabel(app.UIAxes6, 'X')
            ylabel(app.UIAxes6, 'Y')
            zlabel(app.UIAxes6, 'Z')
            app.UIAxes6.Position = [675 305 352 246];

            % Create Label_4
            app.Label_4 = uilabel(app.PPGFeatUIFigure);
            app.Label_4.BackgroundColor = [1 1 1];
            app.Label_4.Position = [1027 0 327 823];
            app.Label_4.Text = ' ';

            % Create Image6
            app.Image6 = uiimage(app.PPGFeatUIFigure);
            app.Image6.Position = [1009 63 359 186];
            app.Image6.ImageSource = fullfile(pathToMLAPP, 'APG-ref.png');

            % Create Image5
            app.Image5 = uiimage(app.PPGFeatUIFigure);
            app.Image5.Position = [1027 340 327 191];
            app.Image5.ImageSource = fullfile(pathToMLAPP, 'VPG-ref.png');

            % Create Label_3
            app.Label_3 = uilabel(app.PPGFeatUIFigure);
            app.Label_3.BackgroundColor = [0.8 0.8 0.8];
            app.Label_3.Position = [1 0 192 824];
            app.Label_3.Text = ' ';

            % Create LoadPPGButton
            app.LoadPPGButton = uibutton(app.PPGFeatUIFigure, 'push');
            app.LoadPPGButton.ButtonPushedFcn = createCallbackFcn(app, @LoadPPGButtonPushed, true);
            app.LoadPPGButton.Position = [16 694 159 23];
            app.LoadPPGButton.Text = 'Load PPG';

            % Create RAWPPGdataLabel
            app.RAWPPGdataLabel = uilabel(app.PPGFeatUIFigure);
            app.RAWPPGdataLabel.Position = [53 669 87 22];
            app.RAWPPGdataLabel.Text = 'RAW PPG data';

            % Create LoadSsqiButton
            app.LoadSsqiButton = uibutton(app.PPGFeatUIFigure, 'push');
            app.LoadSsqiButton.ButtonPushedFcn = createCallbackFcn(app, @LoadSsqiButtonPushed, true);
            app.LoadSsqiButton.Position = [15 633 75 23];
            app.LoadSsqiButton.Text = 'Load Ssqi';

            % Create CSVwithSsqianddataIDLabel
            app.CSVwithSsqianddataIDLabel = uilabel(app.PPGFeatUIFigure);
            app.CSVwithSsqianddataIDLabel.Position = [15 610 147 22];
            app.CSVwithSsqianddataIDLabel.Text = 'CSV with Ssqi and data ID';

            % Create Min1EditFieldLabel
            app.Min1EditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.Min1EditFieldLabel.HorizontalAlignment = 'right';
            app.Min1EditFieldLabel.Position = [234 275 32 22];
            app.Min1EditFieldLabel.Text = 'Min1';

            % Create Image4
            app.Image4 = uiimage(app.PPGFeatUIFigure);
            app.Image4.Position = [1027 621 327 175];
            app.Image4.ImageSource = fullfile(pathToMLAPP, 'PPG-ref.png');

            % Create Min1EditField
            app.Min1EditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.Min1EditField.Position = [281 275 49 22];

            % Create Min2EditFieldLabel
            app.Min2EditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.Min2EditFieldLabel.HorizontalAlignment = 'right';
            app.Min2EditFieldLabel.Position = [342 275 32 22];
            app.Min2EditFieldLabel.Text = 'Min2';

            % Create Min2EditField
            app.Min2EditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.Min2EditField.Position = [389 275 47 22];

            % Create PlotButton
            app.PlotButton = uibutton(app.PPGFeatUIFigure, 'push');
            app.PlotButton.ButtonPushedFcn = createCallbackFcn(app, @PlotButtonPushed, true);
            app.PlotButton.Position = [15 430 159 23];
            app.PlotButton.Text = 'Plot';

            % Create NextButton
            app.NextButton = uibutton(app.PPGFeatUIFigure, 'push');
            app.NextButton.ButtonPushedFcn = createCallbackFcn(app, @NextButtonPushed, true);
            app.NextButton.Position = [15 235 159 23];
            app.NextButton.Text = 'Next';

            % Create IDLabel
            app.IDLabel = uilabel(app.PPGFeatUIFigure);
            app.IDLabel.HorizontalAlignment = 'right';
            app.IDLabel.Position = [458 275 25 22];
            app.IDLabel.Text = 'ID ';

            % Create IDEditField
            app.IDEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.IDEditField.Position = [483 275 29 22];

            % Create GenerateoutputButton
            app.GenerateoutputButton = uibutton(app.PPGFeatUIFigure, 'push');
            app.GenerateoutputButton.ButtonPushedFcn = createCallbackFcn(app, @GenerateoutputButtonPushed, true);
            app.GenerateoutputButton.Position = [16 141 159 23];
            app.GenerateoutputButton.Text = 'Generate output';

            % Create SQI082Good03SQI081AcceptableSQI03UnfitLabel
            app.SQI082Good03SQI081AcceptableSQI03UnfitLabel = uilabel(app.PPGFeatUIFigure);
            app.SQI082Good03SQI081AcceptableSQI03UnfitLabel.Position = [19 516 158 45];
            app.SQI082Good03SQI081AcceptableSQI03UnfitLabel.Text = {'SQI > 0.82       = Good'; '0.3<SQI<0.81  = Acceptable'; 'SQI <0.3          = Unfit'};

            % Create PPGsegmentAPGsegmentFeaturesSegmentlocationsLabel
            app.PPGsegmentAPGsegmentFeaturesSegmentlocationsLabel = uilabel(app.PPGFeatUIFigure);
            app.PPGsegmentAPGsegmentFeaturesSegmentlocationsLabel.FontSize = 14;
            app.PPGsegmentAPGsegmentFeaturesSegmentlocationsLabel.Position = [19 55 143 87];
            app.PPGsegmentAPGsegmentFeaturesSegmentlocationsLabel.Text = {'PPG segment'; 'APG segment'; 'Features'; 'Segment locations'};

            % Create good
            app.good = uilamp(app.PPGFeatUIFigure);
            app.good.Position = [175 545 16 16];

            % Create acceptable
            app.acceptable = uilamp(app.PPGFeatUIFigure);
            app.acceptable.Position = [175 530 16 16];
            app.acceptable.Color = [0.9294 0.6941 0.1255];

            % Create unfit
            app.unfit = uilamp(app.PPGFeatUIFigure);
            app.unfit.Position = [175 515 16 16];
            app.unfit.Color = [1 0 0];

            % Create SkipforbadSsqiButton
            app.SkipforbadSsqiButton = uibutton(app.PPGFeatUIFigure, 'push');
            app.SkipforbadSsqiButton.ButtonPushedFcn = createCallbackFcn(app, @SkipforbadSsqiButtonPushed, true);
            app.SkipforbadSsqiButton.Position = [15 484 159 23];
            app.SkipforbadSsqiButton.Text = 'Skip for bad Ssqi';

            % Create UpdateButton
            app.UpdateButton = uibutton(app.PPGFeatUIFigure, 'push');
            app.UpdateButton.ButtonPushedFcn = createCallbackFcn(app, @UpdateButtonPushed, true);
            app.UpdateButton.Position = [15 327 159 23];
            app.UpdateButton.Text = 'Update';

            % Create SsqiEditFieldLabel
            app.SsqiEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.SsqiEditFieldLabel.HorizontalAlignment = 'right';
            app.SsqiEditFieldLabel.Position = [11 577 29 22];
            app.SsqiEditFieldLabel.Text = 'Ssqi';

            % Create SsqiEditField
            app.SsqiEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.SsqiEditField.Position = [55 577 46 22];

            % Create Label
            app.Label = uilabel(app.PPGFeatUIFigure);
            app.Label.HorizontalAlignment = 'right';
            app.Label.Position = [133 577 25 22];
            app.Label.Text = '';

            % Create Lamp
            app.Lamp = uilamp(app.PPGFeatUIFigure);
            app.Lamp.Position = [173 577 18 18];
            app.Lamp.Color = [1 1 1];

            % Create OEditFieldLabel
            app.OEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.OEditFieldLabel.HorizontalAlignment = 'right';
            app.OEditFieldLabel.Position = [1024 600 16 22];
            app.OEditFieldLabel.Text = 'O';

            % Create OEditField
            app.OEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.OEditField.Position = [1048 600 38 22];

            % Create SEditFieldLabel
            app.SEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.SEditFieldLabel.HorizontalAlignment = 'right';
            app.SEditFieldLabel.Position = [1113 600 13 22];
            app.SEditFieldLabel.Text = 'S';

            % Create SEditField
            app.SEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.SEditField.Position = [1133 600 40 22];

            % Create NEditFieldLabel
            app.NEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.NEditFieldLabel.HorizontalAlignment = 'right';
            app.NEditFieldLabel.Position = [1192 600 25 22];
            app.NEditFieldLabel.Text = 'N';

            % Create NEditField
            app.NEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.NEditField.Position = [1224 600 40 22];

            % Create DEditFieldLabel
            app.DEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.DEditFieldLabel.HorizontalAlignment = 'right';
            app.DEditFieldLabel.Position = [1275 600 25 22];
            app.DEditFieldLabel.Text = 'D';

            % Create DEditField
            app.DEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.DEditField.Position = [1307 600 40 22];

            % Create wEditFieldLabel
            app.wEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.wEditFieldLabel.HorizontalAlignment = 'right';
            app.wEditFieldLabel.Position = [1018 292 25 22];
            app.wEditFieldLabel.Text = 'w';

            % Create wEditField
            app.wEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.wEditField.Position = [1051 292 38 22];

            % Create xEditFieldLabel
            app.xEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.xEditFieldLabel.HorizontalAlignment = 'right';
            app.xEditFieldLabel.Position = [1104 292 25 22];
            app.xEditFieldLabel.Text = 'x';

            % Create xEditField
            app.xEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.xEditField.Position = [1136 292 40 22];

            % Create yEditFieldLabel
            app.yEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.yEditFieldLabel.HorizontalAlignment = 'right';
            app.yEditFieldLabel.Position = [1195 292 25 22];
            app.yEditFieldLabel.Text = 'y';

            % Create yEditField
            app.yEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.yEditField.Position = [1227 292 40 22];

            % Create zEditFieldLabel
            app.zEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.zEditFieldLabel.HorizontalAlignment = 'right';
            app.zEditFieldLabel.Position = [1277 292 25 22];
            app.zEditFieldLabel.Text = 'z';

            % Create zEditField
            app.zEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.zEditField.Position = [1309 292 40 22];

            % Create aEditFieldLabel
            app.aEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.aEditFieldLabel.HorizontalAlignment = 'right';
            app.aEditFieldLabel.Position = [1019 42 25 22];
            app.aEditFieldLabel.Text = 'a';

            % Create aEditField
            app.aEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.aEditField.Position = [1052 42 38 22];

            % Create bEditFieldLabel
            app.bEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.bEditFieldLabel.HorizontalAlignment = 'right';
            app.bEditFieldLabel.Position = [1105 42 25 22];
            app.bEditFieldLabel.Text = 'b';

            % Create bEditField
            app.bEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.bEditField.Position = [1137 42 40 22];

            % Create cmLabel
            app.cmLabel = uilabel(app.PPGFeatUIFigure);
            app.cmLabel.HorizontalAlignment = 'right';
            app.cmLabel.Position = [1195 42 25 22];
            app.cmLabel.Text = 'c ';

            % Create cEditField
            app.cEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.cEditField.Position = [1227 42 40 22];

            % Create dEditFieldLabel
            app.dEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.dEditFieldLabel.HorizontalAlignment = 'right';
            app.dEditFieldLabel.Position = [1277 42 25 22];
            app.dEditFieldLabel.Text = 'd ';

            % Create dEditField
            app.dEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.dEditField.Position = [1309 42 40 22];

            % Create eEditFieldLabel
            app.eEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.eEditFieldLabel.HorizontalAlignment = 'right';
            app.eEditFieldLabel.Position = [1106 9 25 22];
            app.eEditFieldLabel.Text = 'e';

            % Create eEditField
            app.eEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.eEditField.Position = [1138 9 40 22];

            % Create StandardPPGFeaturesLabel
            app.StandardPPGFeaturesLabel = uilabel(app.PPGFeatUIFigure);
            app.StandardPPGFeaturesLabel.BackgroundColor = [0.9412 0.9412 0.9412];
            app.StandardPPGFeaturesLabel.HorizontalAlignment = 'center';
            app.StandardPPGFeaturesLabel.FontSize = 14;
            app.StandardPPGFeaturesLabel.FontWeight = 'bold';
            app.StandardPPGFeaturesLabel.Position = [1039 794 308 25];
            app.StandardPPGFeaturesLabel.Text = 'Standard PPG Features';

            % Create StandardVPGFeaturesLabel
            app.StandardVPGFeaturesLabel = uilabel(app.PPGFeatUIFigure);
            app.StandardVPGFeaturesLabel.BackgroundColor = [0.9412 0.9412 0.9412];
            app.StandardVPGFeaturesLabel.HorizontalAlignment = 'center';
            app.StandardVPGFeaturesLabel.FontSize = 14;
            app.StandardVPGFeaturesLabel.FontWeight = 'bold';
            app.StandardVPGFeaturesLabel.Position = [1039 530 308 31];
            app.StandardVPGFeaturesLabel.Text = 'Standard VPG Features';

            % Create StandardAPGFeaturesLabel
            app.StandardAPGFeaturesLabel = uilabel(app.PPGFeatUIFigure);
            app.StandardAPGFeaturesLabel.BackgroundColor = [0.9412 0.9412 0.9412];
            app.StandardAPGFeaturesLabel.HorizontalAlignment = 'center';
            app.StandardAPGFeaturesLabel.FontSize = 14;
            app.StandardAPGFeaturesLabel.FontWeight = 'bold';
            app.StandardAPGFeaturesLabel.Position = [1039 245 308 30];
            app.StandardAPGFeaturesLabel.Text = 'Standard APG Features';

            % Create canddpresentEditFieldLabel
            app.canddpresentEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.canddpresentEditFieldLabel.HorizontalAlignment = 'right';
            app.canddpresentEditFieldLabel.FontName = 'Times New Roman';
            app.canddpresentEditFieldLabel.FontSize = 16;
            app.canddpresentEditFieldLabel.Position = [757 275 105 22];
            app.canddpresentEditFieldLabel.Text = 'c and d present ';

            % Create canddpresentEditField
            app.canddpresentEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.canddpresentEditField.FontName = 'Times New Roman';
            app.canddpresentEditField.FontSize = 16;
            app.canddpresentEditField.Position = [877 275 18 22];

            % Create Yes0NoLabel
            app.Yes0NoLabel = uilabel(app.PPGFeatUIFigure);
            app.Yes0NoLabel.Position = [913 275 73 22];
            app.Yes0NoLabel.Text = '1: Yes, 0: No';

            % Create Plotallwaveformsusingmin1andmin2Label
            app.Plotallwaveformsusingmin1andmin2Label = uilabel(app.PPGFeatUIFigure);
            app.Plotallwaveformsusingmin1andmin2Label.Position = [19 393 139 30];
            app.Plotallwaveformsusingmin1andmin2Label.Text = {'Plot all waveforms using '; 'min1 and min2'};

            % Create UpdatefeaturepointsusingmodifieduserdefinedvaluesLabel
            app.UpdatefeaturepointsusingmodifieduserdefinedvaluesLabel = uilabel(app.PPGFeatUIFigure);
            app.UpdatefeaturepointsusingmodifieduserdefinedvaluesLabel.Position = [17 288 159 30];
            app.UpdatefeaturepointsusingmodifieduserdefinedvaluesLabel.Text = {'Update feature points using'; 'modified user defined values'};

            % Create GotonextwaveformLabel
            app.GotonextwaveformLabel = uilabel(app.PPGFeatUIFigure);
            app.GotonextwaveformLabel.Position = [28 207 121 22];
            app.GotonextwaveformLabel.Text = 'Go to next waveform ';

            % Create Label_2
            app.Label_2 = uilabel(app.PPGFeatUIFigure);
            app.Label_2.BackgroundColor = [0 0.4471 0.7412];
            app.Label_2.HorizontalAlignment = 'center';
            app.Label_2.WordWrap = 'on';
            app.Label_2.FontName = 'Times New Roman';
            app.Label_2.FontSize = 24;
            app.Label_2.FontWeight = 'bold';
            app.Label_2.FontColor = [1 1 1];
            app.Label_2.Position = [1 824 1353 34];
            app.Label_2.Text = 'PPG Filtering, Segmentation & Fiducial Point Extraction Toolbox';

            % Create PPGFiducialPointsLabel
            app.PPGFiducialPointsLabel = uilabel(app.PPGFeatUIFigure);
            app.PPGFiducialPointsLabel.HorizontalAlignment = 'center';
            app.PPGFiducialPointsLabel.FontName = 'Times New Roman';
            app.PPGFiducialPointsLabel.FontSize = 18;
            app.PPGFiducialPointsLabel.Position = [1027 631 327 25];
            app.PPGFiducialPointsLabel.Text = 'PPG Fiducial Points';

            % Create VPGFiducialPointsLabel
            app.VPGFiducialPointsLabel = uilabel(app.PPGFeatUIFigure);
            app.VPGFiducialPointsLabel.BackgroundColor = [1 1 1];
            app.VPGFiducialPointsLabel.HorizontalAlignment = 'center';
            app.VPGFiducialPointsLabel.FontName = 'Times New Roman';
            app.VPGFiducialPointsLabel.FontSize = 18;
            app.VPGFiducialPointsLabel.Position = [1027 320 327 25];
            app.VPGFiducialPointsLabel.Text = 'VPG Fiducial Points';

            % Create APGFiducialPointsLabel
            app.APGFiducialPointsLabel = uilabel(app.PPGFeatUIFigure);
            app.APGFiducialPointsLabel.HorizontalAlignment = 'center';
            app.APGFiducialPointsLabel.FontName = 'Times New Roman';
            app.APGFiducialPointsLabel.FontSize = 18;
            app.APGFiducialPointsLabel.Position = [1027 68 327 25];
            app.APGFiducialPointsLabel.Text = 'APG Fiducial Points';

            % Create PlotpressedLampLabel
            app.PlotpressedLampLabel = uilabel(app.PPGFeatUIFigure);
            app.PlotpressedLampLabel.Position = [19 369 137 22];
            app.PlotpressedLampLabel.Text = 'Plot pressed';

            % Create PlotpressedLamp
            app.PlotpressedLamp = uilamp(app.PPGFeatUIFigure);
            app.PlotpressedLamp.Position = [171 370 21 21];
            app.PlotpressedLamp.Color = [1 1 1];

            % Create DataTextAreaLabel
            app.DataTextAreaLabel = uilabel(app.PPGFeatUIFigure);
            app.DataTextAreaLabel.HorizontalAlignment = 'right';
            app.DataTextAreaLabel.Position = [531 275 30 22];
            app.DataTextAreaLabel.Text = 'Data';

            % Create DataTextArea
            app.DataTextArea = uitextarea(app.PPGFeatUIFigure);
            app.DataTextArea.Position = [576 274 72 24];

            % Create ExitButton
            app.ExitButton = uibutton(app.PPGFeatUIFigure, 'push');
            app.ExitButton.ButtonPushedFcn = createCallbackFcn(app, @ExitButtonPushed, true);
            app.ExitButton.Position = [16 23 159 23];
            app.ExitButton.Text = 'Exit';

            % Create Label_5
            app.Label_5 = uilabel(app.PPGFeatUIFigure);
            app.Label_5.BackgroundColor = [0.651 0.651 0.651];
            app.Label_5.Position = [1 726 192 98];
            app.Label_5.Text = '';

            % Create FsHzEditFieldLabel
            app.FsHzEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.FsHzEditFieldLabel.HorizontalAlignment = 'right';
            app.FsHzEditFieldLabel.Position = [15 765 44 22];
            app.FsHzEditFieldLabel.Text = 'Fs  (Hz)';

            % Create FsHzEditField
            app.FsHzEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.FsHzEditField.Position = [70 764 106 24];
            app.FsHzEditField.Value = 1000;

            % Create F1Label
            app.F1Label = uilabel(app.PPGFeatUIFigure);
            app.F1Label.HorizontalAlignment = 'right';
            app.F1Label.Position = [11 735 25 22];
            app.F1Label.Text = 'FL';

            % Create FLEditField
            app.FLEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.FLEditField.Position = [42 734 48 24];
            app.FLEditField.Value = 0.4;

            % Create FHEditFieldLabel
            app.FHEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.FHEditFieldLabel.HorizontalAlignment = 'right';
            app.FHEditFieldLabel.Position = [102 735 25 22];
            app.FHEditFieldLabel.Text = 'FH';

            % Create FHEditField
            app.FHEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.FHEditField.Position = [133 734 42 24];
            app.FHEditField.Value = 8;

            % Create EnterSamplingfreqfilterfreqLabel
            app.EnterSamplingfreqfilterfreqLabel = uilabel(app.PPGFeatUIFigure);
            app.EnterSamplingfreqfilterfreqLabel.BackgroundColor = [0.149 0.149 0.149];
            app.EnterSamplingfreqfilterfreqLabel.HorizontalAlignment = 'center';
            app.EnterSamplingfreqfilterfreqLabel.FontName = 'Times New Roman';
            app.EnterSamplingfreqfilterfreqLabel.FontSize = 13;
            app.EnterSamplingfreqfilterfreqLabel.FontColor = [1 1 1];
            app.EnterSamplingfreqfilterfreqLabel.Position = [1 795 192 29];
            app.EnterSamplingfreqfilterfreqLabel.Text = '  Enter Sampling freq & filter freq';

            % Create SkipSsqiCheckBox
            app.SkipSsqiCheckBox = uicheckbox(app.PPGFeatUIFigure);
            app.SkipSsqiCheckBox.Text = 'Skip Ssqi';
            app.SkipSsqiCheckBox.Position = [100 633 75 22];

            % Create fEditFieldLabel
            app.fEditFieldLabel = uilabel(app.PPGFeatUIFigure);
            app.fEditFieldLabel.HorizontalAlignment = 'right';
            app.fEditFieldLabel.Position = [1196 9 21 22];
            app.fEditFieldLabel.Text = 'f';

            % Create fEditField
            app.fEditField = uieditfield(app.PPGFeatUIFigure, 'numeric');
            app.fEditField.Position = [1227 9 40 22];

            % Show the figure after all components are created
            app.PPGFeatUIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = PPGFeat

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.PPGFeatUIFigure)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.PPGFeatUIFigure)
        end
    end
end